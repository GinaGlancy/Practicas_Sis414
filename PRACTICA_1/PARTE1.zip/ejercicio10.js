const filtrarPares = (array) => array.filter(num => num % 2 == 0);
console.log(filtrarPares([1, 2, 3, 4]));


