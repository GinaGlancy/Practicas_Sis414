/*function restar(a, b) {
  return a - b;
}*/

//Funcion fecha

const restar = (a, b) => a - b;
console.log(restar(7, 5));