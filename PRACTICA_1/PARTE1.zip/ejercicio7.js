let usuario = {
    nombre: "Daniel",
    edad: 21
};
for(let clave in usuario) {
    console.log(clave + ": " + usuario[clave]);
}
