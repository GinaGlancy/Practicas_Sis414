let numeros =[1, 2, 3, 4];
let mult = numeros.map(num => num * 2);
console.log(mult);