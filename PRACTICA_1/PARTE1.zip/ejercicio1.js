let nombre ="Gina Glancy Aguirre Mamani";
let edad = 21;
console.log("Hola, mi nombre es "+nombre+" y tengo "+edad+ " años " );