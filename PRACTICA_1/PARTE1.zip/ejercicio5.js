function sumar(a, b){
    return a+b;
}
console.log(sumar(3,5));