let base = 5;
let altura = 3;
let area = base *altura;
console.log(area);