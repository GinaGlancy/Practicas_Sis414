let frutas = ["manzana", "banana", "pera"];
frutas.push("uva");
console.log(frutas);