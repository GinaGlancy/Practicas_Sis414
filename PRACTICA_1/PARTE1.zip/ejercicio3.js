let numero = 4; 
if (numero%2 == 0){
    console.log(numero + " es par");
}else{
    console.log(numero + " es impar");
}